﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ZhouLianFeng_ASP_Demo01.Aspxs.WebTest01 {
    public partial class WebTopic05 : System.Web.UI.Page {
        protected void Page_Load (object sender, EventArgs e) {
            if (IsPostBack) {
                return;
            }

            string picturePath = @"E:\Others IDE Projects\Visual Studio 2022 Projects\ZhouLianFeng_ASP_Demo01\Picture\";
            DirectoryInfo directoryInfo = new DirectoryInfo(picturePath);
            FileInfo[] files = directoryInfo.GetFiles();
            int i = 1;
            foreach (FileInfo file in files) {
                ddlAnimal.Items.Add(new ListItem(i.ToString(),file.Name));
                i++;
            }

            Image1.ImageUrl = @"~\Picture\" + files[0].Name;
        }

        protected void ddlAnimal_SelectedIndexChanged (object sender, EventArgs e) {
            int index = ddlAnimal.SelectedIndex;
            Image1.ImageUrl = @"~\Picture\"+ddlAnimal.Items[index].Value;
        }
    }
}